# -*- coding: utf-8 -*-
# vStream https://github.com/Kodi-vStream/venom-xbmc-addons
# return False  # CF depuis le 26/11/2020
import json

from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
# from resources.lib.parser import cParser
from resources.lib.comaddon import VSlog, VSupdate, progress, siteManager, dialog, addon
from urllib.parse import urlparse
# import xbmcgui
import base64

SITE_IDENTIFIER = 'jya_app'
SITE_NAME = 'JYA'
SITE_DESC = ' films remux'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

URL_SEARCH = (URL_MAIN + 'get_movie_links2', 'showMovies')

# recherche utilisé quand on n'utilise pas le globale
MY_SEARCH_MOVIES = (True, 'showSearchMovie')
MY_SEARCH_SERIES = (True, 'showSearchSerie')

# Menu GLOBALE HOME
MOVIE_MOVIE = (True, 'showMenuMovies')
SERIE_SERIES = (True, 'showMenuTvShows')


def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MY_SEARCH_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, MY_SEARCH_MOVIES[1], 'Recherche Films', 'search.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch(sTmdb2=''):
    oDialog = dialog()
    oDialog.VSinfo('Recherche en cours...')
    # progress = xbmcgui.DialogProgressBG()
    # progress.create("wait", "test")
    # progress.update(50, "recherche" )
    # progress_.VSupdate(progress_, 100)

    oInputParameterHandler = cInputParameterHandler()
    sTmdbId = oInputParameterHandler.getValue('sTmdb')
    sYear = oInputParameterHandler.getValue('sYear')
    sTitle = oInputParameterHandler.getValue('sTitle')
    sName = oInputParameterHandler.getValue('sName')
    sSaison = oInputParameterHandler.getValue('sSaison')
    sEpisode = oInputParameterHandler.getValue('sEpisode')
    sShowName = oInputParameterHandler.getValue('sShowName')
    sNextEpisode = str(int(sEpisode)+1)
    if sSaison:
        sSaison = sSaison.zfill(2)
        sEpisode = sEpisode.zfill(2)
        sNextEpisode = sNextEpisode.zfill(2)

    showMovies(sTmdbId, sTitle, sName, sShowName, sYear, sSaison, sEpisode, sNextEpisode)
    return


def showMovies(sTmdbId, sTitle, sName, sShowName, sYear, sSaison, sEpisode, sNextEpisode, sSearch=''):
    
    sMediaType = "movie" if not sSaison else "tv"    
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    if not sTmdbId:
        sTmdbId = oInputParameterHandler.getValue('sTmdbId')
    oOutputParameterHandler = cOutputParameterHandler()  # Define oOutputParameterHandler
    if sTmdbId:
        oOutputParameterHandler.addParameter('sTmdbId', sTmdbId)  # Utilisé par TMDB
    if sYear:

        oOutputParameterHandler.addParameter('sYear', sYear)  # Utilisé par TMDB
    if sSaison:
        oOutputParameterHandler.addParameter('sSaison', sSaison)
    if sName:
        oOutputParameterHandler.addParameter('sName', sName) # Peut-etre Utilisé par TMDB

    if sSaison:
        sTitle = sShowName
        
    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
    oOutputParameterHandler.addParameter('sRes', '4K')

    # if siteUrl:
    #     sUrl = siteUrl
    # else :
    #     sUrl = URL_MAIN
    # sUrl = siteUrl
    
    sUrl = 'http://jya_app/'
    if sYear:
        sUrl += '&sYear=' + sYear
    if sTmdbId:
        sUrl += '&idTMDB=' + sTmdbId
    sUrl += '&sRes=4k'
    sUrl += '&sTitle=' + sTitle
    if sMediaType == 'tv':
        sUrl += '&sMedia=serie'
        sUrl += '&sSaison=' + sSaison
        sUrl += '&sEpisode=' + sEpisode
    else:
        sUrl += '&sMedia=film'
        
    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    sDisplayTitle = sTitle
    if sMediaType == "tv":
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
        sDisplayTitle = sTitle + ' - ' + sDisplaySaison
        oGui.addTV(SITE_IDENTIFIER, 'showSerieSaisons', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)
    else:
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, 'films.png', '', '', oOutputParameterHandler)
    oGui.setEndOfDirectory()
    
def showHosters():
    oHosterGui = cHosterGui()
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    
    sTmdbId = oInputParameterHandler.getValue('sTmdbId')
    # sTitle = oInputParameterHandler.getValue('sMovieTitle').replace(' | ', ' & ')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sYear = oInputParameterHandler.getValue('sYear')
    sSaison = oInputParameterHandler.getValue('sSeason')
    sEpisode = oInputParameterHandler.getValue('sEpisode')
    sName = oInputParameterHandler.getValue('sName')
    siteUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    sMediaType = "movie" if not sSaison else "tv"
    
    # sThumb = "https://image.tmdb.org/t/p/w1280/wfayeln7TwG6BDxArGJtKwuL67l.jpg"
    # sThumb = oInputParameterHandler.getValue('sThumb')
    
    # progress_ = progress().VScreate(SITE_NAME)
    # progress_.VSupdate(progress_, 100)
    l_magnets_infos = fetch_magnets_info(sTmdbId, sTitle, sMediaType, sSaison, sEpisode)
    
    for torrents_infos in l_magnets_infos:
        file_name = torrents_infos['file_name']
        release_name = torrents_infos['release_name']
        size = torrents_infos['size']
        link = torrents_infos['link']
        title = torrents_infos['title']
        release_year = torrents_infos['release_year']
        language_version = torrents_infos['language_version']
        audio_stream_details = torrents_infos['audio_stream_details']
        video_stream_details = torrents_infos['video_stream_details']
        # progress_.VSupdate(progress_, total)
        oHoster = oHosterGui.checkHoster(link)
        
        if not sYear or len(sYear) == 0:
            sYear = release_year
        if not sTitle:
            sTitle = title
            
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMediaUrl', link)
            
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sTmdbId', sTmdbId)
        oOutputParameterHandler.addParameter('sYear', str(sYear))
        # Important pour marquer vu / progression et déterminer le media type dans kodi
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)

        if sMediaType == 'movie':
            sDisplayName = f"{sTitle} ({release_year})"
        else:
            sDisplayName = sTitle
        sDiplaySize = ''
        sSizeGo = str(round( size / 1_073_741_824,1 ))
        sDiplaySize = ' [COLOR skyblue]['+sSizeGo+'Go][/COLOR]'
        sDisplayName = sDisplayName + sDiplaySize
        oHoster.setSize(size)
        oHoster.setDisplayName(sDisplayName)
        oHoster.setReleaseName(release_name)
        if audio_stream_details is not None:
            oHoster.setAudioStreamDetail(audio_stream_details)
        if video_stream_details is not None:
            oHoster.setVideoStreamDetail(video_stream_details)
        if language_version is not None:
            oHoster.setLanguageVersion(language_version)
        oHosterGui.showHoster(oGui, oHoster, link, '')

    # progress_.VSclose(progress_)
    oGui.setEndOfDirectory()

def fetch_magnets_info(sTmdbId, sQuery, sMediaType, sSaison, sEpisode):
    if not sTmdbId or not sMediaType:
        VSlog("Erreur lors de la requête, un des paramètres n'est pas renseigné")
        return []
    elif sMediaType == 'tv':
        if not sSaison or not sEpisode:
            VSlog("Erreur lors de la requête, un des paramètres n'est pas renseigné")
            return []
    # Préparation des paramètres de la requête
    best_results = addon().getSetting('best_results')
    if best_results == 'true':
        search_mode = 'ygg'
    else:
        search_mode = 'paste'
    if not sSaison:
        sSaison = '0'
        sEpisode = '0'
    params = f"search_mode={search_mode}&query={sQuery}&season={sSaison}&episode={sEpisode}"
    api_token_jya = addon().getSetting('hoster_jya_token')
    parsed_url_jya = urlparse(addon().getSetting('url_jya'))
    full_host = f"{parsed_url_jya.scheme}://{parsed_url_jya.hostname}{':'+parsed_url_jya.port if parsed_url_jya.port else ''}"
    url_jya = f"{full_host}/search/{sMediaType}/{sTmdbId}"
    credentials = f"{addon().getSetting('username_jya')}:{addon().getSetting('password_jya')}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    try:
        # Création et configuration de la requête
        oRequest = cRequestHandler(url_jya)
        oRequest.addHeaderEntry('Content-Type', 'application/json')
        oRequest.addHeaderEntry('Authorization', f'Basic {encoded_credentials}')
        oRequest.addHeaderEntry('Authorization-Bearer', f'{api_token_jya}')
        oRequest.setTimeout(70) # 70 secondes
        oRequest.setRequestType(0)
        oRequest.addParametersLine(params)
        res = oRequest.request()
        jsonRes = json.loads(res)
        l_magnets_infos = jsonRes['data']['links']
        return l_magnets_infos
    except Exception as e:
        # Gestion de l'erreur HTTP 404 ou autre
        if hasattr(e, 'code') and e.code == 404:
            VSlog(f"Erreur 404: Ressource non trouvée pour l'URL {url_jya} avec les paramètres {params}")
        else:
            VSlog(f"Erreur lors de la requête: {str(e)}")
        return []

def showSerieSaisons():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    siteUrl = oInputParameterHandler.getValue('siteUrl')
    searchTitle = oInputParameterHandler.getValue('sMovieTitle')

    # Pour supporter les caractères '&' et '+' dans les noms alors qu'ils sont réservés
    sUrl = siteUrl.replace('+', ' ').replace('|', '+').replace(' & ', ' | ')

    oOutputParameterHandler = cOutputParameterHandler()

    sSaison = oInputParameterHandler.getValue('sSaison')
    
    sDisplaySaison = sSaison
    if sSaison.isdigit():
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
        sDisplayTitle = searchTitle + ' - ' + sDisplaySaison
    else:
        sDisplaySaison = sDisplaySaison.replace('Episodes ', '').replace('(', '').replace(')', '')
        sDisplayTitle = '[' + sDisplaySaison + ']' + ' - ' + searchTitle
    
    # sUrl = siteUrl + '&sSaison=' + sSaison
    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle) # on ne passe pas sTitre afin de pouvoir mettre la saison en marque-page
    oGui.addSeason(SITE_IDENTIFIER, 'showEpisodesLinks', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)

    oGui.setEndOfDirectory()
    
def showEpisodesLinks(siteUrl=''):
    oGui = cGui()

    if not siteUrl:
        oInputParameterHandler = cInputParameterHandler()
        siteUrl = oInputParameterHandler.getValue('siteUrl')

    # Pour supporter les caractères '&' et '+' dans les noms alors qu'ils sont réservés
    sUrl = siteUrl.replace('+', ' ').replace('|', '+').replace(' & ', ' | ')
    params = sUrl.split('&', 1)[1]
    aParams = dict(param.split('=') for param in params.split('&'))
    sSaison = aParams['sSaison'] if 'sSaison' in aParams else None
    sEpisode = aParams['sEpisode'] if 'sEpisode' in aParams else None
    searchTitle = aParams['sTitle'].replace(' | ', ' & ')

    if not sSaison:
        oGui.setEndOfDirectory()
        return

    sDisplaySaison = sSaison
    if sSaison.isdigit():
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
    elif 'P' in sDisplaySaison:
        sDisplaySaison = ''

    oOutputParameterHandler = cOutputParameterHandler()

    sUrl = siteUrl

    if str(sEpisode).isdigit():
        sEpisode = '{}E{:02d}'.format(sDisplaySaison, int(sEpisode))
    else:
        sEpisode = '{}{}'.format(sDisplaySaison, sEpisode)
    sDisplayTitle = searchTitle + ' - ' + sEpisode

    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle)
    # oOutputParameterHandler.addParameter('sSaison', sSaison)
    # oOutputParameterHandler.addParameter('sEpisode', sEpisode)
    oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)
    oGui.setEndOfDirectory()