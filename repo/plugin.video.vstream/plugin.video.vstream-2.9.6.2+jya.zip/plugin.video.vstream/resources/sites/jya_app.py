# -*- coding: utf-8 -*-
# vStream https://github.com/Kodi-vStream/venom-xbmc-addons
# return False  # CF depuis le 26/11/2020
import json
import re

from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
# from resources.lib.parser import cParser
from resources.lib.comaddon import VSlog, VSupdate, progress, siteManager, dialog
from resources.lib.util import cUtil, Unquote
import xbmcgui

SITE_IDENTIFIER = 'jya_app'
SITE_NAME = 'JYA'
SITE_DESC = ' films remux'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

URL_SEARCH = (URL_MAIN + 'get_movie_links2', 'showMovies')

# recherche utilisé quand on n'utilise pas le globale
MY_SEARCH_MOVIES = (True, 'showSearchMovie')
MY_SEARCH_SERIES = (True, 'showSearchSerie')

# Menu GLOBALE HOME
MOVIE_MOVIE = (True, 'showMenuMovies')
SERIE_SERIES = (True, 'showMenuTvShows')


def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MY_SEARCH_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, MY_SEARCH_MOVIES[1], 'Recherche Films', 'search.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch(sTmdb2=''):
    VSlog("showSearch")
    oDialog = dialog()
    oDialog.VSinfo('Recherche en cours...')
    # progress = xbmcgui.DialogProgressBG()
    # progress.create("wait", "test")
    # progress.update(50, "recherche" )
    # progress_.VSupdate(progress_, 100)

    oInputParameterHandler = cInputParameterHandler()
    sTmdbId = oInputParameterHandler.getValue('sTmdb')
    sYear = oInputParameterHandler.getValue('sYear')
    sTitle = oInputParameterHandler.getValue('sTitle')
    sName = oInputParameterHandler.getValue('sName')
    sSaison = oInputParameterHandler.getValue('sSaison')
    sEpisode = oInputParameterHandler.getValue('sEpisode')
    sShowName = oInputParameterHandler.getValue('sShowName')
    sNextEpisode = str(int(sEpisode)+1)
    if sSaison:
        sSaison = sSaison.zfill(2)
        sEpisode = sEpisode.zfill(2)
        sNextEpisode = sNextEpisode.zfill(2)
    
    VSlog(oInputParameterHandler.getAllParameter())
    VSlog("sTmdbId")
    VSlog(sTmdbId)
    VSlog("sYear")
    VSlog(sYear)
    VSlog("sTitle")
    VSlog(sTitle)
    VSlog("sName")
    VSlog(sName)
    VSlog("sSaison")
    VSlog(sSaison)
    VSlog("sEpisode")
    VSlog(sEpisode)

    showMovies(sTmdbId, sTitle, sName, sShowName, sYear, sSaison, sEpisode, sNextEpisode)
    return


def showMovies(sTmdbId, sTitle, sName, sShowName, sYear, sSaison, sEpisode, sNextEpisode, sSearch=''):
    
    sMediaType = "movie" if not sSaison else "tv"    
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    siteUrl = oInputParameterHandler.getValue('siteUrl')
    # sYear = oInputParameterHandler.getValue('sYear')
    # sTitle = oInputParameterHandler.getValue('sTitle')
    if not sTmdbId:
        sTmdbId = oInputParameterHandler.getValue('sTmdbId')
    oOutputParameterHandler = cOutputParameterHandler()  # Define oOutputParameterHandler
    VSlog(sYear)
    if sTmdbId:
        VSlog("--------------------------sTmdbId")
        VSlog(sTmdbId)
        oOutputParameterHandler.addParameter('sTmdbId', sTmdbId)  # Utilisé par TMDB
    if sYear:

        oOutputParameterHandler.addParameter('sYear', sYear)  # Utilisé par TMDB
    if sSaison:
        oOutputParameterHandler.addParameter('sSaison', sSaison)
    if sName:
        oOutputParameterHandler.addParameter('sName', sName) # Peut-etre Utilisé par TMDB
    
    VSlog("sTitle")
    VSlog(sTitle)
    if sSaison:
        sTitle = sShowName
        
    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
    oOutputParameterHandler.addParameter('sRes', '4K')

    # if siteUrl:
    #     sUrl = siteUrl
    # else :
    #     sUrl = URL_MAIN
    # sUrl = siteUrl
    
    sUrl = 'http://jya_app/'
    if sYear:
        sUrl += '&sYear=' + sYear
    if sTmdbId:
        sUrl += '&idTMDB=' + sTmdbId
    sUrl += '&sRes=4k'
    sUrl += '&sTitle=' + sTitle
    if sMediaType == 'tv':
        sUrl += '&sMedia=serie'
        sUrl += '&sSaison=' + sSaison
        sUrl += '&sEpisode=' + sEpisode
    else:
        sUrl += '&sMedia=film'
        
    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    sDisplayTitle = sTitle
    if sMediaType == "tv":
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
        sDisplayTitle = sTitle + ' - ' + sDisplaySaison
        oGui.addTV(SITE_IDENTIFIER, 'showSerieSaisons', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)
    else:
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, 'films.png', '', '', oOutputParameterHandler)
    oGui.setEndOfDirectory()
    
def showHosters():
    oHosterGui = cHosterGui()
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    
    VSlog("showHosters - oInputParameterHandler.getAllParameter()")
    VSlog(oInputParameterHandler.getAllParameter())
    
    sTmdbId = oInputParameterHandler.getValue('sTmdbId')
    # sTitle = oInputParameterHandler.getValue('sMovieTitle').replace(' | ', ' & ')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sYear = oInputParameterHandler.getValue('sYear')
    sSaison = oInputParameterHandler.getValue('sSeason')
    sEpisode = oInputParameterHandler.getValue('sEpisode')
    sName = oInputParameterHandler.getValue('sName')
    siteUrl = oInputParameterHandler.getValue('siteUrl')
    VSlog("siteUrlBON")
    VSlog(siteUrl)
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    sMediaType = "movie" if not sSaison else "tv"
    
    # sThumb = "https://image.tmdb.org/t/p/w1280/wfayeln7TwG6BDxArGJtKwuL67l.jpg"
    # sThumb = oInputParameterHandler.getValue('sThumb')
    
    VSlog("id_tmdb")
    # VSlog(sSearch)
    # progress_ = progress()

    # progress_ = progress().VScreate(SITE_NAME)
    # progress_.VSupdate(progress_, 100)
    l_magnets_infos = fetch_magnets_info(sTmdbId, sMediaType, sSaison, sEpisode)
    
    
    VSlog("sYear")
    VSlog(sYear)
    
    for torrents_infos in l_magnets_infos:
        if 'filename' in torrents_infos:
            torrent_title = torrents_infos['filename']
            filesize = torrents_infos['filesize']
            movie_link = torrents_infos['link']
            title = torrents_infos['title']
            release_year = torrents_infos['release_year']
            VSlog("release_year")
            VSlog(release_year)
        # progress_.VSupdate(progress_, total)
        oHoster = oHosterGui.checkHoster(movie_link)
        
        if not sYear or len(sYear) == 0:
            sYear = release_year
        if torrent_title != '':
            sCleanReleaseName = getCleanReleaseNameByUrl(torrent_title)
        else:
            sCleanReleaseName = getCleanReleaseNameByUrl(movie_link)
        # if sMediaType == 'tv':
        #     sTitle = sName
        #     VSlog("sTtileRelease")
        #     VSlog(sTitle)
        if not sTitle:
            sTitle = title
            
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMediaUrl', movie_link)
            
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sTmdbId', sTmdbId)
        oOutputParameterHandler.addParameter('sYear', str(sYear))
        # Important pour marquer vu / progression et déterminer le media type dans kodi
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)

        # VSlog(oOutputParameterHandler.getParameterAsUri())
        if sMediaType == 'movie':
            sDisplayName = sTitle +' ('+release_year+')'
        else:
            sDisplayName = sTitle
        VSlog("showHosters - sDisplayName")
        VSlog(sDisplayName)
        sDiplaySize = ''
        sSizeGo = str(round( filesize / 1_073_741_824,1 ))
        sDiplaySize = ' [COLOR skyblue]['+sSizeGo+'Go][/COLOR]'
        sDisplayName = sDisplayName + sDiplaySize
        oHoster.setSize(filesize)
        oHoster.setDisplayName(sDisplayName)
        # oHoster.setFileName(sDisplayName)
        oHoster.setReleaseName(sCleanReleaseName)
        oHoster.setVideoStreamDetail(getVideoStreamDetail(sCleanReleaseName))
        oHoster.setAudioStreamDetail(getAudioStreamDetail(sCleanReleaseName))
        oHosterGui.showHoster(oGui, oHoster, movie_link, '')

    # progress_.VSclose(progress_)
    oGui.setEndOfDirectory()

def fetch_magnets_info(sTmdbId, sMediaType, sSaison, sEpisode):
    """
    Récupère les informations de magnets à partir de l'API /get_media_links.
    
    Args:
        sTmdbId (str): ID TMDB du média.
        sMediaType (str): Type de média (movie/tv).
        sSaison (str): Numéro de la saison (pour les séries TV).
        sEpisode (str): Numéro de l'épisode (pour les séries TV).
    
    Returns:
        list: Liste des informations de magnets récupérées.
    """
    if not sTmdbId or not sMediaType:
        VSlog(f"Erreur lors de la requête, un des paramètres n'est pas renseigné")
        return []
    elif sMediaType == 'tv':
        if not sSaison or not sEpisode:
            VSlog(f"Erreur lors de la requête, un des paramètres n'est pas renseigné")
            return []
    # Préparation des paramètres de la requête
    params = f'tmdbid={sTmdbId}&mediatype={sMediaType}&season={sSaison}&episode={sEpisode}'
    url = 'http://192.168.1.50:3000/get_media_links'
    try:
        # Création et configuration de la requête
        oRequest = cRequestHandler(url)
        oRequest.setTimeout(60)
        oRequest.setRequestType(0)  # Assurez-vous que 0 correspond bien au type GET dans votre contexte
        oRequest.addParametersLine(params)

        # Envoi de la requête et traitement de la réponse
        res = oRequest.request()

        # Parsing du JSON retourné
        jsonRes = json.loads(res)

        # Logging de la réponse JSON (optionnel)
        VSlog(jsonRes)

        # Extraction des informations des liens magnets
        l_magnets_infos = jsonRes['data']['links']

        return l_magnets_infos
    except Exception as e:
        # Gestion de l'erreur HTTP 404 ou autre
        if hasattr(e, 'code') and e.code == 404:
            VSlog(f"Erreur 404: Ressource non trouvée pour l'URL {url} avec les paramètres {params}")
        else:
            VSlog(f"Erreur lors de la requête: {str(e)}")
        return []

def getCleanReleaseNameByUrl(sHosterUrl):
    sReleaseName = sHosterUrl.split('/')[-1]
    sReleaseName = Unquote(sReleaseName)
    sOriginalReleaseName = sReleaseName
    # regex pour garder seulement ce qu'il y a après la date
    dateEpisodesPattern = r"(?:(?!1080|2160)\d{4}|S\d{1,2}E\d{1,2})(?:[\s.()\[\]-]*)(.*)"
    match = re.search(dateEpisodesPattern, sReleaseName)
    if match:
        sReleaseName = match.group(1).strip()
    # regex pour retirer l'id TMDB du film
    tmPattern = r"TM\d+TM"
    sReleaseName = re.sub(tmPattern, '', sReleaseName)
    # On retire les '.mkv', on garde les .mp4
    sReleaseName = re.sub(r'.mkv', '', sReleaseName)
    # On retire les points + espaces en fin de nom
    sReleaseName = re.sub(r'[.\s]+$', '', sReleaseName)
    if len(sReleaseName) < 20:
        sReleaseName = sOriginalReleaseName+" "
    return sReleaseName


def getVideoStreamDetail(sCleanReleaseName):
    videoStreamDetail = {}
    hdrType = None
    videoCodec = None
    aspectRatio = 2.38
    dolbyvision_words = ['dv', 'dovi', 'dolbyvision', 'dolby.vision']
    hdr10plus_words = ['hdr10+', 'hdr10p']
    sLowerCleanReleaseName = sCleanReleaseName.lower()
    uhd_words = ['uhd', '4k', '2160']
    fhd_words = ['1080', 'fhd', 'fullhd', 'full hd', 'full-hd']
    if any(word in sLowerCleanReleaseName for word in uhd_words):
        width = 3840
        height = 2160
    elif any(word in sLowerCleanReleaseName for word in fhd_words):
        width = 1920
        height = 1080
    elif '720' in sLowerCleanReleaseName:
        width = 1280
        height = 720
    else:
        width = 0
        height = 0
    videoStreamDetail['width'] = width
    videoStreamDetail['height'] = height
    if any(word in sLowerCleanReleaseName for word in dolbyvision_words):
        hdrType = 'dolbyvision'
    elif any(word in sLowerCleanReleaseName for word in hdr10plus_words):
        hdrType = 'hdr10'
    elif 'hdr' in sLowerCleanReleaseName:
        hdrType = 'HDR'
        hdrType = 'hdr10'
    if hdrType is not None :
        videoStreamDetail['hdrtype'] = hdrType
    h265_words = ['h265','x265','hevc']
    h264_words = ['h264','x264','avc']
    if any(word in sLowerCleanReleaseName for word in h265_words):
        videoCodec = 'h265'
    elif any(word in sLowerCleanReleaseName for word in h264_words):
        videoCodec = 'h264'
    if videoCodec is not None :
        videoStreamDetail['codec'] = videoCodec
        videoStreamDetail['aspect'] = aspectRatio
    VSlog("videoStreamDetail")
    VSlog(videoStreamDetail)
    return videoStreamDetail

def getAudioStreamDetail(sCleanReleaseName):
    sLowerCleanReleaseName = sCleanReleaseName.lower()
    language = ''
    audioCodec = ''
    channels = 0
    if '7.1' in sLowerCleanReleaseName:
        channels = 8
    elif '5.1' in sLowerCleanReleaseName or '6ch' in sLowerCleanReleaseName:
        channels = 6
    vff_words = ['vff', 'vfi', 'vfo', 'vof', 'vf2', 'truefrench', 'true french']
    if any(word in sLowerCleanReleaseName for word in vff_words):
        language = 'fr'
    dtshdma_words = ['hdma','dtshd','dts.hd','dts-hd']
    eac3_words = ['eac3','dd+','ddp']
    truehd_words = ['thd','truehd','true-hd','true.hd','truhd']
    dtsx_words = ['dts-x','dtsx','dts:x']
    if any(word in sLowerCleanReleaseName for word in dtshdma_words):
        audioCodec = 'dtshdma'
    elif any(word in sLowerCleanReleaseName for word in dtsx_words):
        audioCodec = 'dtsx'
    elif any(word in sLowerCleanReleaseName for word in truehd_words):
        audioCodec = 'truehd'
    elif any(word in sLowerCleanReleaseName for word in eac3_words):
        audioCodec = 'eac3'
    elif 'ac3' in sLowerCleanReleaseName:
        audioCodec = 'ac3'
    audioStreamDetail = {'codec': audioCodec, 'channels':channels, 'language':language}
    return audioStreamDetail

def showSerieSaisons():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    siteUrl = oInputParameterHandler.getValue('siteUrl')
    searchTitle = oInputParameterHandler.getValue('sMovieTitle')

    # Pour supporter les caractères '&' et '+' dans les noms alors qu'ils sont réservés
    sUrl = siteUrl.replace('+', ' ').replace('|', '+').replace(' & ', ' | ')

    oOutputParameterHandler = cOutputParameterHandler()

    sSaison = oInputParameterHandler.getValue('sSaison')
    
    sDisplaySaison = sSaison
    if sSaison.isdigit():
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
        sDisplayTitle = searchTitle + ' - ' + sDisplaySaison
    else:
        sDisplaySaison = sDisplaySaison.replace('Episodes ', '').replace('(', '').replace(')', '')
        sDisplayTitle = '[' + sDisplaySaison + ']' + ' - ' + searchTitle
    
    # sUrl = siteUrl + '&sSaison=' + sSaison
    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle) # on ne passe pas sTitre afin de pouvoir mettre la saison en marque-page
    oGui.addSeason(SITE_IDENTIFIER, 'showEpisodesLinks', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)

    oGui.setEndOfDirectory()
    
def showEpisodesLinks(siteUrl=''):
    oGui = cGui()
    
    VSlog("ShowEpisodesLinks - getEpisodeListing")
    VSlog(oGui.getEpisodeListing())

    if not siteUrl:
        oInputParameterHandler = cInputParameterHandler()
        siteUrl = oInputParameterHandler.getValue('siteUrl')

    # Pour supporter les caractères '&' et '+' dans les noms alors qu'ils sont réservés
    sUrl = siteUrl.replace('+', ' ').replace('|', '+').replace(' & ', ' | ')
    params = sUrl.split('&', 1)[1]
    aParams = dict(param.split('=') for param in params.split('&'))
    sSaison = aParams['sSaison'] if 'sSaison' in aParams else None
    sEpisode = aParams['sEpisode'] if 'sEpisode' in aParams else None
    searchTitle = aParams['sTitle'].replace(' | ', ' & ')

    if not sSaison:
        oGui.setEndOfDirectory()
        return

    sDisplaySaison = sSaison
    if sSaison.isdigit():
        sDisplaySaison = 'S{:02d}'.format(int(sSaison))
    elif 'P' in sDisplaySaison:
        sDisplaySaison = ''

    oOutputParameterHandler = cOutputParameterHandler()

    sUrl = siteUrl

    if str(sEpisode).isdigit():
        sEpisode = '{}E{:02d}'.format(sDisplaySaison, int(sEpisode))
    else:
        sEpisode = '{}{}'.format(sDisplaySaison, sEpisode)
    sDisplayTitle = searchTitle + ' - ' + sEpisode

    oOutputParameterHandler.addParameter('siteUrl', sUrl)
    oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle)
    # oOutputParameterHandler.addParameter('sSaison', sSaison)
    # oOutputParameterHandler.addParameter('sEpisode', sEpisode)
    oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, 'series.png', '', '', oOutputParameterHandler)
    oGui.setEndOfDirectory()